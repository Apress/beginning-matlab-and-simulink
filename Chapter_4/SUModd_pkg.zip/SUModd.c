/*
 * Academic License - for use in teaching, academic research, and meeting
 * course requirements at degree granting institutions only.  Not for
 * government, commercial, or other organizational use.
 * File: SUModd.c
 *
 * MATLAB Coder version            : 4.1
 * C/C++ source code generated on  : 25-Aug-2019 13:39:43
 */

/* Include Files */
#include "SUModd.h"

/* Function Definitions */

/*
 * Arguments    : double N
 * Return Type  : void
 */
void SUModd(double N)
{
  (void)N;
}

/*
 * File trailer for SUModd.c
 *
 * [EOF]
 */
