/*
 * Academic License - for use in teaching, academic research, and meeting
 * course requirements at degree granting institutions only.  Not for
 * government, commercial, or other organizational use.
 * File: SUModd_terminate.h
 *
 * MATLAB Coder version            : 4.1
 * C/C++ source code generated on  : 25-Aug-2019 13:39:43
 */

#ifndef SUMODD_TERMINATE_H
#define SUMODD_TERMINATE_H

/* Include Files */
#include <stddef.h>
#include <stdlib.h>
#include "rtwtypes.h"
#include "SUModd_types.h"

/* Function Declarations */
extern void SUModd_terminate(void);

#endif

/*
 * File trailer for SUModd_terminate.h
 *
 * [EOF]
 */
