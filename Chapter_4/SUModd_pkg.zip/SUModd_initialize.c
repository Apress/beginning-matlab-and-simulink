/*
 * Academic License - for use in teaching, academic research, and meeting
 * course requirements at degree granting institutions only.  Not for
 * government, commercial, or other organizational use.
 * File: SUModd_initialize.c
 *
 * MATLAB Coder version            : 4.1
 * C/C++ source code generated on  : 25-Aug-2019 13:39:43
 */

/* Include Files */
#include "SUModd.h"
#include "SUModd_initialize.h"

/* Function Definitions */

/*
 * Arguments    : void
 * Return Type  : void
 */
void SUModd_initialize(void)
{
}

/*
 * File trailer for SUModd_initialize.c
 *
 * [EOF]
 */
